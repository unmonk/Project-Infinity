from .pytmx import *
from .tmxloader import load_pygame

__version__ = (3, 19, 0)
__author__ = 'bitcraft'
__author_email__ = 'leif.theden@gmail.com'
__description__ = 'Map loader for TMX Files - Python 2 and 3'
Need pyTMX library to use

Members: Scott Weaver  & Ryan Sample


Done in this version:
basic movement
fixed sprite loading
pytmx use for maps




todo:
-Sprite needs a redo. - Going to use individual pngs instead of a sheet.
-fix physics
-Add enemy
-Add more levels

-audio


-gui


-gamesave

- py2EXE









__author__ = 'Scott'

import os
SCREEN_WIDTH = 1280
SCREEN_HEIGHT = 720
GAME_TITLE = "Project Infinity"
MAP_COLLISION_LAYER = 1
BACKGROUND_COLOR = (20, 20, 20)




PLAYERPATH = 'resources/images/player'

IMAGE_PATH = {
    'playerIdle': [os.path.join(PLAYERPATH, 'Idle_000.png'), os.path.join(PLAYERPATH, 'Idle_001.png'), os.path.join(PLAYERPATH, 'Idle_002.png'), os.path.join(PLAYERPATH, 'Idle_003.png'), os.path.join(PLAYERPATH, 'Idle_004.png'),
                   os.path.join(PLAYERPATH, 'Idle_005.png'), os.path.join(PLAYERPATH, 'Idle_006.png'), os.path.join(PLAYERPATH, 'Idle_007.png'), os.path.join(PLAYERPATH, 'Idle_008.png'), os.path.join(PLAYERPATH, 'Idle_009.png')],

    'playerJump': []


}